function tampilPesan() {
    alert("Terima kasih telah mengunjungi Website OSIS!");
}
